import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../services/dashboard.service';

@Component({
  selector: 'app-toll-table',
  templateUrl: './toll-table.component.html',
  styleUrls: ['./toll-table.component.css']
})
export class TollTableComponent implements OnInit {

  public tableHeader = ['Sl No', 'Toll Name', 'Inbond Direction', 'Inbond Congestion', 'Outbond Diterction',
    'Outbond Congestion', 'State', 'NH No', 'Contract Company'];

  public tableData = [
    {
      tollId: '1',
      tollName: 'Abc',
      inbondCongestionDistance: '100',
      outbondCongestionDistance: '300',
      inbondStatus: 'Low',
      outbondStatus: 'Moderate',
      nhNum: '4',
      state: 'Karnataka',
      contractCompany: 'L&T',
      inbondDirection: 'Towards a',
      outbondDirection: 'Towards b',
    },
    {
      tollId: '2',
      tollName: 'Abc',
      inbondCongestionDistance: '100',
      outbondCongestionDistance: '300',
      inbondStatus: 'Low',
      outbondStatus: 'High',
      nhNum: '4',
      state: 'Karnataka',
      contractCompany: 'L&T',
      inbondDirection: 'Towards a',
      outbondDirection: 'Towards b',
    },
    {
      tollId: '3',
      tollName: 'Abc',
      inbondCongestionDistance: '100',
      outbondCongestionDistance: '300',
      inbondStatus: 'High',
      outbondStatus: 'Moderate',
      nhNum: '4',
      state: 'Karnataka',
      contractCompany: 'L&T',
      inbondDirection: 'Towards a',
      outbondDirection: 'Towards b',
    },
    {
      tollId: '4',
      tollName: 'Abc',
      inbondCongestionDistance: '100',
      outbondCongestionDistance: '300',
      inbondStatus: 'Moderate',
      outbondStatus: 'High',
      nhNum: '4',
      state: 'Karnataka',
      contractCompany: 'L&T',
      inbondDirection: 'Towards a',
      outbondDirection: 'Towards b',
    },
    {
      tollId: '5',
      tollName: 'Abc',
      inbondCongestionDistance: '100',
      outbondCongestionDistance: '300',
      inbondStatus: 'Low',
      outbondStatus: 'High',
      nhNum: '4',
      state: 'Karnataka',
      contractCompany: 'L&T',
      inbondDirection: 'Towards a',
      outbondDirection: 'Towards b',
    },
    {
      tollId: '3',
      tollName: 'Abc',
      inbondCongestionDistance: '100',
      outbondCongestionDistance: '300',
      inbondStatus: 'High',
      outbondStatus: 'Moderate',
      nhNum: '4',
      state: 'Karnataka',
      contractCompany: 'L&T',
      inbondDirection: 'Towards a',
      outbondDirection: 'Towards b',
    },
    {
      tollId: '4',
      tollName: 'Abc',
      inbondCongestionDistance: '100',
      outbondCongestionDistance: '300',
      inbondStatus: 'Moderate',
      outbondStatus: 'High',
      nhNum: '4',
      state: 'Karnataka',
      contractCompany: 'L&T',
      inbondDirection: 'Towards a',
      outbondDirection: 'Towards b',
    },
    {
      tollId: '5',
      tollName: 'Abc',
      inbondCongestionDistance: '100',
      outbondCongestionDistance: '300',
      inbondStatus: 'Low',
      outbondStatus: 'High',
      nhNum: '4',
      state: 'Karnataka',
      contractCompany: 'L&T',
      inbondDirection: 'Towards a',
      outbondDirection: 'Towards b',
    }
  ];

  public response: any;

  constructor(public dashboardService: DashboardService) {
    this.response = this.dashboardService.dashboardTableResponse;
  }

  ngOnInit() {
  }

}
